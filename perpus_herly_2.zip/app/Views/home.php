<div class="container">
    <h1>Selamat datang di Perpustakaan</h1>
    <p>Ini adalah halaman pertama dari perpustakaan.</p>
    <a href="/login" class="btn btn-primary">Login HTML</a>
    <button class="btn btn-primary" onclick="window.location.href='/login'" id="login-js">Login JS</button>
    <a href="/register" class="btn btn-danger">Register HTML</a>
</div>